const { MessageEmbed } = require("discord.js");
module.exports = {
    config: {
        name: "help",
        aliases: ["ajuda"],
    },
    run: async(client, message, args) => {
        const help = client.music.players.get(message.guild.id);
        message.channel.send(new MessageEmbed()
        .setTitle("Meu comandos de Musicas")
        .setColor('RANDOM')
        .setDescription(`
        
                my!play \`<nome da música/url>\` - Escolhe uma música para tocar.
                my!stop - Para a música.
                my!skip - Pula uma música.
                my!playlist - Mostra aleatoriamente um número.
                my!pause - Pausa a música.
                my!resume - Retoma a música.
                my!tocando - Mostra a música que esta tocando no momento.
                my!volume \`<altura>\` - Define o volume da música.
                
                [adicioner o Bot](https://discord.com/oauth2/authorize?client_id=759201532603400262&scope=bot&permissions=66403648)
                
                [suporte](https://discord.gg/YUa7NKm)
        `))
    },
};





/*
const Discord = require('discord.js');

exports.run = async (client, message, args) => {
message.delete();
  let avatar = message.author.displayAvatarURL({ format: 'png' });
  const embed = new Discord.MessageEmbed()
    .setTitle("Meu comandos de Músicas")
    //.setURL('https://discord.gg/vA4TgsK')
    .setColor('#FF1493')
    .setDescription(`        
                !play \`<nome da música/url>\` - Escolhe uma música para tocar.
                !stop - Para a música.
                !skip - Pula uma música.
                !playlist - Mostra aleatoriamente um número.
                !pause - Pausa a música.
                !resume - Retoma a música.
                !tocando - Mostra a música que esta tocando no momento.
                !volume \`<altura>\` - Define o volume da música.\n \n [suporte](https://discord.gg/vA4TgsK)`)
    .setImage("https://media1.tenor.com/images/7c7195f5e6119519a1e22b5207ebf412/tenor.gif?itemid=13918708")
    .setThumbnail(avatar)
    .setFooter('Código de Gabriel Discord')
    .setAuthor(message.author.tag, avatar);
  await message.channel.send(embed);
}
//Código foi feito pelo gabriel
*/