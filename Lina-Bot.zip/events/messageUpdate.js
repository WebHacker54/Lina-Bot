const { MessageEmbed } = require("discord.js");
module.exports = async (oldMessage, newMessage) => {
  try {
    let embed = new MessageEmbed()
      .setTitle(`Nova message editada`)
      .setColor(`GREEN`)
      .setDescription(
        `**O usuário ${oldMessage.author.tag} editou uma mensagem no canal <#${oldMessage.channel.id}>**`
      )
      .addField(`Mensagem antiga:`, oldMessage.content, true)
      .addField(`Nova mensagem:`, newMessage.content, true);
    let channel = oldMessage.guild.channels.cache.find(
      (ch) => ch.name === "etbilu-logs"
    );
    if (!channel) return;
    channel.send(embed);
  } catch (e) {}
};