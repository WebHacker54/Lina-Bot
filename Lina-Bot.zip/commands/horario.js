const Discord = require("discord.js") // declarar Discord

exports.run = async(message, bot, args) => {

  let embed = new Discord.MessageEmbed() // construtor embed
  .setTimestamp() // Data de agora
 message.channel.send(embed) // enviando embed
};