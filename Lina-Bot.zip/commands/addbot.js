const Discord = require("discord.js")
exports.run = async ( client, message, agr) => {          

           message.channel.send("**Qual o nome do seu Bot?**").then(msg1 => {

              let pergunta1 = message.channel.createMessageCollector(t => t.author.id === message.author.id, {max: 1})

                .on('collect', t => {

                  let pergunta1 = t.content

             message.channel.send("**Qual o ID do seu Bot?**").then(msg2 => {

            let pergunta2 = message.channel.createMessageCollector(d => d.author.id === message.author.id, {max: 1})

                .on('collect', d => {

                  let pergunta2 = d.content

            

             message.channel.send("**Qual o prefixo do seu Bot?**").then(msg3 => {

            let pergunta3 = message.channel.createMessageCollector(d => d.author.id === message.author.id, {max: 1})

                .on('collect', d => {

                  let pergunta3 = d.content

             message.channel.send("**Mande o link do seu Bot**").then(msg4 => {

            let pergunta4 = message.channel.createMessageCollector(d => d.author.id === message.author.id, {max: 1})

                .on('collect', d => {

                  let pergunta4 = d.content


             
                  message.channel.send(`@(💎)Supervisor Olhe o #🧣¬logs-bots !!!`)
                  const teste = new Discord.MessageEmbed()

                    .setColor('#FFB6C1')

                    .setTitle("Add Bot")

                    .setDescription(`**Qual o nome do seu Bot?**\n ${pergunta1}\n\n **Qual o ID do seu Bot?**\n ${pergunta2}\n\n **Qual o prefixo do seu Bot?**\n ${pergunta3}\n\n **Link do seu Bot**\n ${pergunta4}\n\n @(💎)Supervisor`)

                    .setFooter("Formulário feito por: "+message.author.username, message.author.displayAvatarURL({size: 32}))


                client.channels.cache.get('764622137226428466').send(teste)


                  message.channel.send(`${message.author}**o seu Formulario foi enviado com sucesso!**`)

                })

               })

              })

             })

            })

           })

          })

         })

}