const Discord = require('discord.js');

const db = require('quick.db');

module.exports = {
    name: "warn",
    description: "Warn a member",

    async run (client, message, args) {

        const user = message.mentions.users.first() || message.guild.members.cache.get(args[0]);

        if(!user) return message.channel.send('Especifique um usuário, por meio de menção ou ID');

        if(user.bot) return message.channel.send('Você não pode dar rep em bots');

        if(message.author.id === user.id) return message.channel.send('Você não pode se dar um rep');

        let warnings = db.get(`warnings_${message.guild.id}_${user.id}`);


        if(warnings === null) {
            db.set(`warnings_${message.guild.id}_${user.id}`, 1);
            user.send(`Você ganhou 1 rep em ${message.guild.name}`)
            await message.channel.send(`**${user.username}** ganhou 1 rep`)
        }

        if(warnings !== null){
            db.add(`warnings_${message.guild.id}_${user.id}`, 1)
            user.send(`Você ganhou 1 rep no servidor ${message.guild.name}`)
            await message.channel.send(`**${user.username}** Ganhou 1 rep`)
        }
    }
}