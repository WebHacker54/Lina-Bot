const Discord = require('discord.js')

exports.run = async (bot, message, args) => {
  let embed = new Discord.MessageEmbed()
    .setTitle("Verificação!")
    .setDescription("Reaja no emoji da bandeira do Brasil para desbloqueiar o servidor em pt-Br")
    .setFooter("Verificação")
message.channel.send(embed);
}