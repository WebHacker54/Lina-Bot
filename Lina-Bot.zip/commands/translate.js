const translate = require('@vitalets/google-translate-api');
const Discord = require('discord.js');
const langs = {
    "auto": "Automatic",
    "ar": "Arabe",
    "nl": "Holandes",
    "eng": "Inglês",
    "en": "Inglês",
    "fr": "Frances",
    "de": "Alemão",
    "el": "Grego",
    "it": "Italiano",
    "ja": "Japones",
    "jw": "Javanes",
    "kn": "Kannada",
    "ko": "Coreano",
    "pt": "Portugues",
    "ro": "Romano",
    "ru": "Russo",
    "es": "Espanhol"
};
 (client, message, args) => {
 
  if (!args[0]) {
    return message.channel.send(`Ta errado esse comando ae, use da seguinte forma: a!translate <linguagem> + <linguagem> <oq quer traduzir>`)
  }
  
  let msg = args.slice(2).join(' ');
  translate(msg, { from: args[0], to: args[1] }).then(res => {
     let embed = new Discord.MessageEmbed()
      .setAuthor(`${message.author.username}`)
      .setTitle(`ETBilu Translate`)
      .setColor('RANDOM')
      .setThumbnail('https://upload.wikimedia.org/wikipedia/commons/d/db/Google_Translate_Icon.png')
      .setDescription(`Linguagens do texto traduzido: ` + "`" + `${langs[args[0]]}` + "`" + " e " + "`" + `${langs[args[1]]}` + "`")
      .setFooter(`Comando executado por: ${message.author.tag}`, message.author.avatarURL)
      .addField('Texto não traduzido:', msg)
      .addField(`Texto traduzido:`, res.text)   
      .setTimestamp()
    
    message.channel.send(embed)
  

  }).catch(err => {
    console.log(err)
    message.channel.send('Essa linguagem não existe.')
  })
};