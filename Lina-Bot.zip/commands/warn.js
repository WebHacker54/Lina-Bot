const Discord = require('discord.js');

const db = require('quick.db');

module.exports = {
    name: "warn",
    description: "Warn a member",

    async run (client, message, args) {
        if(!message.member.hasPermission("MANAGE_MESSAGES")) return message.channel.send('Você não pode usar esse comando');

        const user = message.mentions.users.first() || message.guild.members.cache.get(args[0]);

        if(!user) return message.channel.send('Especifique um usuário, por meio de menção ou ID');

        if(user.bot) return message.channel.send('Você não pode dar warn em bots');

        if(message.author.id === user.id) return message.channel.send('Você não pode se dar um warn');

        if(message.guild.owner.id === user.id) return message.channel.send('Você não pode dar warn no dono do servidor');

        let reason = args.slice(1).join(" ");

        if(!reason) reason = 'Não especificado';

        let warnings = db.get(`warnings_${message.guild.id}_${user.id}`);

        if(warnings === 3) return message.channel.send(`Hey! o ${user} já alcançou 3 warns`);


        if(warnings === null) {
            db.set(`warnings_${message.guild.id}_${user.id}`, 1);
            user.send(`Você foi avisado em ${message.guild.name} pelo seguinte motivo: \`${reason}\``)
            await message.channel.send(`**${user.username}** foi avisado`)
        }

        if(warnings !== null){
            db.add(`warnings_${message.guild.id}_${user.id}`, 1)
            user.send(`Você ganhou 1 warn no servidor ${message.guild.name} Pelo seguinte motivo: \`${reason}\``)
            await message.channel.send(`**${user.username}** Ganhou 1 warn`)
        }
    }
}