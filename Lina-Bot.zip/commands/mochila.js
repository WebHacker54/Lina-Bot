const Discord = require('discord.js')
const db = require('quick.db')

exports.run = async(client, message, args) => {
      let user = message.mentions.users.first() || message.author; //this will show us money of the user we mention & if we don't mentin it will show ours
    let pistola = db.fetch(`pistola_${user.id}`) // this will fetch the amount we have
    let bala = db.fetch(`bala_${user.id}`)
    let carne = db.fetch(`carne_${user.id}`)
    let arma2 = db.fetch(`caça_${user.id}`)

       if (pistola === null) pistola = 0;
       if (bala === null) bala = 0;
       if (carne === null) carne = 0;
       if (arma2 === null) arma2 = 0;
   let embed = new Discord.MessageEmbed()
   .setTitle(`**Mochila do(a): ${user.username}**`)
   .setThumbnail('https://images-ext-1.discordapp.net/external/BYin3qQ4OVdyW7vtGrQZGp6MZTaYdz824sSho3Uf57Y/%3Fsize%3D2048/https/cdn.discordapp.com/avatars/739218168391925780/d40bcb4966be1a8f3de95656a11e8c02.png?width=586&height=586')
    .setColor("RANDOM")
    .setDescription(`Armas: ${pistola}\n Munições:${bala}\n Carnes:${carne}`)
    .setTimestamp()
    .setFooter(`${user.username}`)
  message.channel.send(embed)
  //lets test it
}

module.exports.help = {
  name: "balance",
  aliases: ["bal"]
}