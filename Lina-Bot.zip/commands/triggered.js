const Discord = require('discord.js');
const superfetch = require("node-superfetch"); // npm install node-superfetch
exports.run = async (client, message, args, prefix) => {
  let user = message.mentions.users.first() || client.users.cache.get(args[0]) || message.author;
  const {body} = await superfetch.get(`https://eclyssia-api.tk/api/v1/triggered?url=${user.avatarURL}`)
  const attachment = new Discord.Attachment(body, 'tr.gif');
  await message.channel.send(attachment);
}