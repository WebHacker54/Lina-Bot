const Discord = require('discord.js')

exports.run = (client, message, args) => {    
  let replies = ["Fui roubado da lorrita com sucesso!"];
  let result = Math.floor((Math.random() * replies.length));
  let question = args.slice(0).join(" ");
message.channel.createWebhook('Vieirinha', {
avatar: 'https://loritta.website/assets/img/vieirinha.png'}).then(w => {
w.send(replies[result])
})
  message.delete()
}