const Discord = require("discord.js")
const db = require('quick.db')
exports.run = async (client, message, args, arg_texto, chat) => {

  let guild = client.guilds.cache.get(message.guild.id)

   if (message.content.includes('-')) { // if the message includes "-" do this.
        return message.channel.send('Dinheiro negativo não pode compra itens')
    }

 if (!args[0]) {
 const help = new Discord.MessageEmbed()
     .setColor("#FFFFFF")
    .setTitle('Lojinha Do Téozinho')
    .setDescription(`\n**Utilize ^loja + <produtos>**\n\nProdutos\n\nArmas\nmunições\npescar\noutros`)
    .setFooter(`${guild.name}`, message.guild.iconURL({format: "png"}))
    .setTimestamp();    
    
 return message.channel.send(help).then(msg => {
  })

  } else if (message.content.includes("armas")) {
      const embed = new Discord.MessageEmbed()
    .setTitle('Vendas de Armas')
    .setDescription(':one: | ***Pistola*** - 1 por 7,000 <:emoji_1:751247486571511870>\n:two: | ***Munições*** - 30 por 3,000 <:emoji_1:751247486571511870>')
message.channel.send(embed).then(msg => {
    msg.react('753437590497132575').then(r => {
      msg.react('753437619160875128').then(r => {
        })
  })
    
    const infosFilter = (reaction, user) => reaction.emoji.id === '753437590497132575' && user.id === message.author.id;
        const admFilter = (reaction, user) => reaction.emoji.id === '753437619160875128' && user.id === message.author.id;
      
    const infos = msg.createReactionCollector(infosFilter);
        const adm = msg.createReactionCollector(admFilter);
    
    infos.on('collect', r2 => {
       if (message.content.includes('-')) { // if the message includes "-" do this.
        return message.channel.send('Dinheiro negativo não pode compra itens')
    }

      embed.setTitle("Você acaba de comprar")
      embed.setDescription("1 pistola por 7,000 <:emoji_1:751247486571511870>")
    
      msg.edit(embed)
     db.add(`pistola_${message.author.id}`, 1)


      db.subtract(`talentos_${message.author.id}`, 3000)
})

    adm.on('collect', r2 => {
       if (message.content.includes('-')) { // if the message includes "-" do this.
        return message.channel.send('Dinheiro negativo não pode compra itens')
    }

      
      embed.setTitle("Você acaba de comprar")
      embed.setDescription("30 munição por 3,000 <:emoji_1:751247486571511870>")
      msg.edit(embed)
    
       
 db.add(`bala_${message.author.id}`, 30)
      db.subtract(`talentos_${message.author.id}`, 3000)
})
 

    
      
})
}
}



/*
:one: - Cartucho com 30 Balas | R$ 5,000
:two: - Vara de Pesca | R$ 15,000
:three: - 7 Camarões | R$ 5,000
*/
/* msg.edit(embed2)
    }, 3000) // 1000 ms = 1s
    setTimeout(() => {*/
    /* message.content === "1" 
        message.content.reply('manutenção')*/ 