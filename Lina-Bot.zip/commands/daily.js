const db = require('quick.db')
const ms = require('parse-ms')
const Discord = require('discord.js')

exports.run = async (client, message, args, config) => {


    let timeout = 86400000 // 7 days in milliseconds, change if you'd like.
    let amount = 1000
    // random amount: Math.floor(Math.random() * 1000) + 1;


    let weekly = await db.fetch(`weekly_${message.author.id}`);

    if (weekly !== null && timeout - (Date.now() - weekly) > 0) {
        let time = ms(timeout - (Date.now() - weekly));

        message.channel.send(`Você só pode coletar daqui a **${time.days}d ${time.hours}h ${time.minutes}m ${time.seconds}s**!`)
    } else {
    let embed = new Discord.MessageEmbed()
    .setAuthor(`Daily de Marte`, message.author.displayAvatarURL)
    .setColor("GREEN")
    .setDescription(`**Daily do ETBilu**\n Você recebeu:`, amount)

    message.channel.send(embed)
    db.set(`weekly_${message.author.id}`, Date.now())
        
    }

}