const Discord = require("discord.js")
module.exports.run = async (client, message, args) => {

var nomes = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10']; 
var name = nomes[Math.floor(Math.random() * nomes.length)];
console.log(name);
const embed = new Discord.MessageEmbed()
        .setColor(0x808080)
        .setTitle(`** :star: | Parabéns Você recebeu:**`)
        .setDescription(`\`⚡ ${name} ⚡\``)
        .setFooter(`RikkaManager© Todos os Direitos Reservados`, message.author.displayAvatarURL({ dynamic: true }))
        
        message.channel.send(embed);
}