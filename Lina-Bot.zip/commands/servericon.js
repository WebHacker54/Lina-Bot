let user = message.mentions.users.first() || client.users.cache.get(args[0]) || message.author;
  
  var server = 
  let server = server.iconURL({ dynamic: true, format: "png", size: 1024 });

  let embed = new Discord.MessageEmbed() 
    .setColor(`#4cd8b2`) 
    .setTitle(`🖼Icon do server ${server.username}`) 
    .setImage(avatar) 
    .setFooter(`• Autor: ${message.author.tag}`, message.author.displayIconURL({format: "png"}));
 message.channel.send(embed); 

};