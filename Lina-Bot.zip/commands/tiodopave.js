const Discord = require('discord.js')

exports.run = (client, message, args) => {    
  let replies = ["Fui roubado da lorrita com sucesso!"];
  let result = Math.floor((Math.random() * replies.length));
  let question = args.slice(0).join(" ");
message.channel.createWebhook('Tio do Pave', {
avatar: 'https://pbs.twimg.com/profile_images/1159262033206026240/_zZLlAJ6_400x400.png'}).then(w => {
w.send(replies[result])
})
  message.delete()
}