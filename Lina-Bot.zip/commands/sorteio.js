const ms = require('ms');

module.exports = {
    name: "giveaway",
    description: "Starts a giveaway",

    async run(client, message, args) {
        if (!message.member.hasPermission("MANAGE_MESSAGES")) return message.channel.send('You are not allowed to start giveaways');

        let channel = message.mentions.channels.first();

        if (!channel) return message.channel.send('Porfavor selecione um canal!');

        let giveawayDuration = args[1];

        if (!giveawayDuration || isNaN(ms(giveawayDuration))) return message.channel.send('Porfavor selecione um tempo valido');

        let giveawayWinners = args[2];

        if (isNaN(giveawayWinners) || (parseInt(giveawayWinners) <= 0)) return message.channel.send('Porfavor selecione um numero de vencedores valido!');

        let giveawayPrize = args.slice(3).join(" ");

        if (!giveawayPrize) return message.channel.send('Ok então\n Eu não vou dar nada');

        client.giveawaysManager.start(channel, {
            time: ms(giveawayDuration),
            prize: giveawayPrize,
            winnerCount: giveawayWinners,
            hostedBy: client.config.hostedBy ? message.author : null,

            messages: {
                giveaway: (client.config.everyoneMention ? "@everyone\n\n" : "") + "GIVEAWAY",
                giveawayEned: (client.config.everyoneMention ? "@everyone\n\n" : "") + "GIVEAWAY ENDED",
                timeRemaining: "Time remaining: **{duration}**",
                inviteToParticipate: "Reaja com 🎉 para participar",
                winMessage: "Parabéns! {winners}, você(s) ganhou(ganharam) **{prize}**",
                embedFooter: "Tempo do sorteio!",
                noWinner: "Não foi possivel determinar um vencedor!",
                hostedBy: "Criado por {user}",
                winners: "Ganhador(es)",
                endedAt: "Termina em",
                units: {
                    seconds: "seconds",
                    minutes: "minutes",
                    hours: "hours",
                    days: "days",
                    pluralS: false
                }
            }
        })

        message.channel.send(`Sorteio criado no canal ${channel}`);
    }
}