const Discord = require("discord.js")
const db = require('quick.db')
exports.run = async (client, message, args, arg_texto, chat) => {

const embed = new Discord.MessageEmbed()
    .setTitle('Trabalhos disponiveis')
    .setDescription('🦌 | Caçador\n🐟 | Pescador')
message.channel.send(embed).then(msg => {
    msg.react('🦌').then(r => {
      msg.react('🐟').then(r => {
        })
  })
    
    const infosFilter = (reaction, user) => reaction.emoji.id === '🦌' && user.id === message.author.id;
        const admFilter = (reaction, user) => reaction.emoji.id === '🐟' && user.id === message.author.id;
      
    const infos = msg.createReactionCollector(infosFilter);
        const adm = msg.createReactionCollector(admFilter);
    
    infos.on('collect', r2 => {
      embed.setTitle("Novo Trabalho!")
      embed.setColor("#303136")
      embed.setDescription("Você acaba de virar um **Caçador**\n\n Dica: compre uma arma de caça")
    
      msg.edit(embed)
     db.add(`cacador_${message.author.id}`, 1)
      })
    
    adm.on('collect', r2 => {
      embed.setColor("#303136")
      embed.setDescription("Você acabar de virar um **Pescador**\n\n Dica: compre uma vara de pesca")
      msg.edit(embed)
    
       
 db.add(`pescador_${message.author.id}`, 1)
    })
})

}
