const Discord = require('discord.js')
const db = require('quick.db')

module.exports.run = async (client, message, args, config) => {



    

    let member = db.fetch(`talentos_${message.author.id}`)
    
  
  
    if (!args[0]) {
        return message.channel.send('Escreva um valor para ser depositado.')
    }
   if (message.content.includes('-')) { // if the message includes "-" do this.
        return message.channel.send('ETCoins negativos não podem ser depositados.')
    }

    if (member < args[0]) {
        return message.channel.send(`Você não possui essa quantia.`)
    }

     let embed = new Discord.MessageEmbed()
    .setTitle(`Depósito de Marte`)
    .setColor("GREEN")
    .setDescription(`🏧 | Você depositou ${args[0]} ETCoins no seu Banco de Marte com sucesso`)
    .setTimestamp()
    .setFooter(`•${message.author.tag}`, message.author.displayAvatarURL({format: "png"}));

    message.channel.send(embed)
    db.add(`banco_${message.author.id}`, args[0])
    db.subtract(`talentos_${message.author.id}`, args[0])




}