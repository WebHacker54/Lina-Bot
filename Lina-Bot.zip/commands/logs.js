const db = require("quick.db")
module.exports.run = async (bot, message, args) => {

let canal = message.mentions.channels.first() || client.guilds.cache.get(message.guild.id).channels.cache.get(args[0])


db.set('userInfo', { channel: canal })





  }

module.exports.help = {
    name: "logs",
    aliases: ["logs"]
}