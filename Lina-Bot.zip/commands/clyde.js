exports.run = async (client, message, args) => {
	 const sayMessage = args.join(' ');
const { clyde } = require('ayla-npm')

message.channel.send(clyde({
 message: sayMessage //<-- aqui vc poderá colocar a msg quer vc quer ou no caso um "args" ja feito =/
}))
}