
const Discord = require("discord.js");
const superagent = require("superagent");

console.lod(body)

exports.run = async (bot, message, args) => {

    let body = await superagent
  .get(`https://i.imgur.com/VQi7xiv.jpg`);

  let catembed = new Discord.MessageEmbed()
  .setColor("RANDOM")
  .setTitle("Pandas 🐼")
  .setImage(body.file);

  message.channel.send(catembed);
}


exports.help = {
    name:"gato" 
 }