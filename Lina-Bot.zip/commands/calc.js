// This command require 2 packages -- discord.js & mathjs

const math = require('mathjs');
const Discord = require('discord.js');

exports.run = (client, message, args) => {


  // First, we want to check if they input text
  if (!args[0]) return message.channel.send('Porfavor coloque uma conta.');

  // Then, we want to try to evaluate the calculation  using the mathjs package
  let resp;
  try {
      resp = math.evaluate(args.join(' '));
  } catch (e) {
    console.log(e)
      return message.channel.send('Desculpa, coloque uma conta válida');
  }

  // Finally send the output
  const embed = new Discord.MessageEmbed()
      .setColor('#11ff00')
      .setTitle('Calculadora!')
      .addField('Calculo',  `\`\`\`js\n${args.join('')}\`\`\``)
      .addField('Resultado', `\`\`\`js\n${resp}\`\`\``)

  message.channel.send(embed);

  // Now, we can test it!    

}