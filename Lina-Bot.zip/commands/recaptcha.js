const { captcha } = require('ayla-npm');
const Discord = require("discord.js")

module.exports = {
  name: 'captcha',
  run: (client, message, args) => {
  
  let ct = captcha({
    message: args
  })
  
  message.channel.send(ct)
  
   }
}
