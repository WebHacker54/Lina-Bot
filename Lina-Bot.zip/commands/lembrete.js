const Discord = require('discord.js');
const moment = require('moment');

module.exports.run = async (client, message, args) => {
    var time = args[0];
    var mensagem = args.splice(1).join(' ');
    if(!time)
    if(!mensagem)



    time = await time.toString();

    if (time.indexOf('s') !== -1) { // Segundos
        var timesec = await time.replace(/s.*/, '');
        var timems = await timesec * 1000;
    } else if (time.indexOf('m') !== -1) { // Minutos
        var timemin = await time.replace(/m.*/, '');
        timems = await timemin * 60 * 1000;
    } else if (time.indexOf('h') !== -1) { // Horas
        var timehour = await time.replace(/h.*/, '');
        timems = await timehour * 60 * 60 * 1000;
    } else if (time.indexOf('d') !== -1) { // Dias
        var timeday = await time.replace(/d.*/, '');
        timems = await timeday * 60 * 60 * 24 * 1000;
    }    else {
        return message.reply('Insira o tempo desejado! `[s/m/h/d]`');
    }

let fidp = new Discord.MessageEmbed()
  .setAuthor(`${message.author.username}`, client.user.displayAvatarURL({ dynamic: true }))
  .setTimestamp()
  .setTitle(`👽 • Lembrete`)
  .setDescription(`Lembrete criado com sucesso! | Irei mandar em sua dm em ${time} sobre ${mensagem}!`)
  .setColor("RANDOM")
  

  
// :)
  return message.channel.send(fidp)


    setTimeout(function () {
    let embed2 = new Discord.MessageEmbed()
        .setColor(0x808080)
        .setTitle('`\⏰\` Lembrete!')
        .addField(`**⏰ | Lembrete de \`${mensagem}\`!**`, `⠀`)
        .addField(`🔖 | Lembrete de \`${time}\``, `⠀`)
        .setFooter(`RikkaManager© Todos os Direitos Reservados`, message.author.displayAvatarURL({ dynamic: true }))

        message.member.send(embed2)
    }, parseInt(timems));

}

module.exports.help = {
    name: 'lembrete'
}