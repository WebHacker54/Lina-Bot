const Discord = require('discord.js')
const db = require('quick.db')

exports.run = async(client, message, args) => {
      let user = message.mentions.users.first() || message.author; //this will show us money of the user we mention & if we don't mentin it will show ours
   let talentos = db.fetch(`talentos_${user.id}`) // this will fetch the amount we have
    let banco = db.fetch(`banco_${user.id}`)
       if (talentos === null) talentos = 0;
       if (banco === null) banco = 0;
   let embed = new Discord.MessageEmbed()
   .setTitle(`👽 ETCoins | **${user.username}**`)
    .setColor("GREEN")
    .setDescription(`\n💸 | **Carteira:** ${talentos}\n\n🏛 | **Banco:** ${banco}\n`)
    .setTimestamp()
    .setFooter(`${user.username}`)
  message.channel.send(embed)
  //lets test it
}

module.exports.help = {
  name: "balance",
  aliases: ["bal"]
}