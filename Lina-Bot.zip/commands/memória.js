const Discord = require("discord.js")

module.exports.run = (bot, message, args) => {
 const status = new Discord.MessageEmbed()
 .setTitle('<:config:770735873712848926> Status')
 .addField('__Meu CPU:__', `**${(process.cpuUsage().system / 1024 / 1024).toFixed(2)}%**`)
 .addField('__Minha RAM:__', `**${(process.memoryUsage().rss / 1024 / 1024).toFixed(2)}MB**`)
message.reply(status)
}