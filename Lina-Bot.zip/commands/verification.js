const Discord = require('discord.js')

exports.run = async (bot, message, args) => {
  let embed = new Discord.MessageEmbed()
    .setTitle("Verification!")
    .setDescription("React to the blue flag emoji to unlock the English server")
    .setFooter("Verification")
message.channel.send(embed);
}