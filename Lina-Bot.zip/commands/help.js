const Discord = require('discord.js')
const config = require("../config.json")

exports.run = (bot, message, args) => {
  let embed = new Discord.MessageEmbed()
    .setTitle('`Lina | Painel de Suporte!`')
    .addField("<a:simboldiscord:770492764177039380> | Clique Nas Reacôes Para Abrir As Categorias.", `\n\n\n\n\n<a:v_number1:770491314528976917> | **Comandos Moderação**\n\n<a:v_number2:770491352794005505> | **Comandos De Economia**\n\n <a:v_number3:770491376039100436> | **Comandos De Info**\n\n<a:v_number4:770491398431571968> | **Comandos de Diversão**\n\n<a:u_SetaEsquerda:770490714937098261> | **Voltar Aqui**\n\n[Me Adicione?](https://discord.com/api/oauth2/authorize?client_id=778767912424701952&permissions=1610075590&scope=bot)\n[Meu Suporte!](https://discord.gg/vQAaEPmBS8)`)
    .setColor("#EC1FD1")
    .setThumbnail("https://media.discordapp.net/attachments/766027262121345055/779381374100045824/1605889361844.png?width=270&height=270")
    .setImage("https://cdn.discordapp.com/attachments/770488915122585613/779355424347914261/1605883063246.png")
    .setFooter(`${message.author.tag} Lina • Painel de Suporte`, message.author.avatarURL)
  message.channel.send({ embed }).then(msg => {
    msg.react('770491314528976917').then(r => {
      msg.react('770491352794005505')
      msg.react('770491376039100436')
      msg.react('770491398431571968')
      msg.react('770490714937098261')
    })

    const UtilidadesFilter = (reaction, user, ) => reaction.emoji.id === '770491314528976917' && user.id === message.author.id;
    const ModeraçãoFilter = (reaction, user, ) => reaction.emoji.id === '770491352794005505' && user.id === message.author.id;
    const InfoFilter = (reaction, user, ) => reaction.emoji.id === '770491376039100436' && user.id === message.author.id;
    const DiversãoFilter = (reaction, user, ) => reaction.emoji.id === '770491398431571968' && user.id === message.author.id;
    const BackFilter = (reaction, user, ) => reaction.emoji.id === '770490714937098261' && user.id === message.author.id;
    const Utilidades = msg.createReactionCollector(UtilidadesFilter, { time: 80000 });
    const Moderação = msg.createReactionCollector(ModeraçãoFilter, { time: 80000 });
    const Info = msg.createReactionCollector(InfoFilter, { time: 80000 });
    const Diversão = msg.createReactionCollector(DiversãoFilter, { time: 80000 });
    const Back = msg.createReactionCollector(BackFilter, { time: 80000 });

    Utilidades.on('collect', r2 => {
      embed = new Discord.MessageEmbed()
        .setTitle("<a:v_number1:770491314528976917> | Comandos de Moderação")
        .setDescription(`<:Seta_Lina:779422577705615360> .avatar - Pegue O Avatar De Alguem ||Funciona Menção||\n<:Seta_Lina:779422577705615360> .clima - Veja O Clima De Algum Lugar\n<:Seta_Lina:779422577705615360> .hex - Veja O Hex, A Cor E O Nome Da Cor\n<:Seta_Lina:779422577705615360> .invisible - Pegue Caracteres Invisiveis\n<:Seta_Lina:779422577705615360> .sorteio - Crie Um Sorteio\n<:Seta_Lina:779422577705615360> .adv - De Uma Adivertençia Em Algume!\n<:Seta_Lina:779422577705615360> .advs - Veja Advs Na Pessoas`)
        .setThumbnail("https://media.discordapp.net/attachments/766027262121345055/779381374100045824/1605889361844.png?width=270&height=270")
        .setImage("https://cdn.discordapp.com/attachments/770488915122585613/779355424347914261/1605883063246.png")
        .setColor("#ff00c8")
      msg.edit(embed);
    })

    Moderação.on('collect', r2 => {
      embed = new Discord.MessageEmbed()
        .setTitle("<a:v_number2:770491352794005505> | Comandos para Economia")
        .setDescription(`<:Seta_Lina:779422577705615360> .trabalhar - Para Trabalhar Em Seu Escritório\n<:Seta_Lina:779422577705615360> .crime - Para Cometer Um Crime.\n<:Seta_Lina:779422577705615360> .daily - Para Ganhar Seu Dinheiro Diario\n<:Seta_Lina:779422577705615360> .semanal - Para Pegar Seu Dinheiro Semanal.\n<:Seta_Lina:779422577705615360> .roubar - Em Breve\n<:Seta_Lina:779422577705615360> .perfil - Para Ver Seu Perfil\n\n<:Seta_Lina:779422577705615360> Tudo Ainda Não Está Pegando Da Economia.`)
        .setColor("#303136")
      msg.edit(embed);
    })

    Info.on('collect', r2 => {
      embed = new Discord.MessageEmbed()
        .setTitle("<a:v_number3:770491376039100436> | Comandos de Informações")
        .setDescription(`<:Seta_Lina:779422577705615360> .botinfo - saiba mais sobre o bot!\n<:Seta_Lina:779422577705615360> .serverinfo - saiba mais sobre o sv!\n<:Seta_Lina:779422577705615360> .userinfo - saiba mais sobre um user!\n<:Seta_Lina:779422577705615360> .github - veja a github de alguem!\n<:Seta_Lina:779422577705615360> .memória - veja minha RAM e CPU`)
        .setColor("#303136")
      msg.edit(embed);
    })

    Diversão.on('collect', r2 => {
      embed = new Discord.MessageEmbed()
        .setTitle("<a:v_number4:770491398431571968> | Comandos para Diversão")
        .setDescription(`<:Seta_Lina:779422577705615360> .say - faça o bot falar algo!\n<:Seta_Lina:779422577705615360> .dog - veja alguns dogs fofinhos\n<:Seta_Lina:779422577705615360> .cat - veja alguns gatinhos fofinhos\n<:Seta_Lina:779422577705615360> .faketweet - tweete alguma coisa fake!\n<:Seta_Lina:779422577705615360> .8ball - faça perguntas e veja suas respostas!\n<:Seta_Lina:779422577705615360> .bigtext - escreva aglo usando emojis!\n<:Seta_Lina:779422577705615360> .biscoito - de um biscoito ha alguem!\n<:Seta_Lina:779422577705615360> .calc - calcule alguns numeros e veja o resultado!\n<:Seta_Lina:779422577705615360> .coinflip - jogue cara ou coroa!\n<:Seta_Lina:779422577705615360> .jokempo - jogue uma pertida de pedra papel ou tesoura contra o bot!\n<:Seta_Lina:779422577705615360> .kiss - beije alguém!\n<:Seta_Lina:779422577705615360> .lenny - me faça enviar uma carinha engraçada!\n<:Seta_Lina:779422577705615360> .morse - um código morse irá aparecer!\n<:Seta_Lina:779422577705615360> .roll - jogue os dados e veja o numero!\n<:Seta_Lina:779422577705615360> .ship - faça um ship de 2 pessoas!\n<:Seta_Lina:779422577705615360> .reverse - escreva algo e sairá ao contrário!\n<:Seta_Lina:779422577705615360> .laranjo - faça o laranjo falar algo!\n<:Seta_Lina:779422577705615360> .clyde - faça a clyde falar algo\n<:Seta_Lina:779422577705615360> .recaptcha - escreva algo para REcaptcha\n<:Seta_Lina:779422577705615360> .random - veja um numero aleatório!\n<:Seta_Lina:779422577705615360> .dados - jogue os dados e veja o numero!\n <:Seta_Lina:779422577705615360> .rep - de uma reputação a alguem!\n a!reps - veja a reputação de alguem!`)
        .setColor("#303136")
      msg.edit(embed);
    })

    Back.on('collect', r2 => {
      embed = new Discord.MessageEmbed()
        .setTitle('Lina | Painel de Suporte!')
        .addField("<a:simboldiscord:770492764177039380> | Clique Nas Reacôes Para Abrir As Categorias.", `\n\n\n\n\n<a:v_number1:770491314528976917> **Comandos Moderação**\n\n<a:v_number2:770491352794005505> | **Comandos De Economia**\n\n <a:v_number3:770491376039100436> | **Comandos De Info**\n\n<a:v_number4:770491398431571968> | **Comandos de Diversão**\n\n<a:u_SetaEsquerda:770490714937098261> | **Voltar Aqui**\n\n[Me Adicione?](https://discord.com/api/oauth2/authorize?client_id=778767912424701952&permissions=1610075590&scope=bot)\n[Meu Suporte!](https://discord.gg/vQAaEPmBS8)`)
        .setColor("#EC1FD1")
        .setThumbnail("https://media.discordapp.net/attachments/766027262121345055/779381374100045824/1605889361844.png?width=270&height=270")
        .setImage("https://cdn.discordapp.com/attachments/770488915122585613/779355424347914261/1605883063246.png")
        .setFooter(`${message.author.tag} Lina • Painel de Suporte`, message.author.avatarURL)
      msg.edit(embed);
    })
  });
};