const Discord = require("discord.js")

exports.run = async(bot, message, args) => {
  
  let embed = new Discord.MessageEmbed();
  
    .setTitle("Shunshin!")
    .setDescription(`${autor.username} chegou como?\n Na quela sarrada com shunshin né\n Tlgd`}
    .setFooter("Sasukeeee")
    .setImage("https://i.pinimg.com/originals/81/d9/d4/81d9d47736b6ea92a2c1958ff3c21957.png")
  message.channel.send(embed);
  }