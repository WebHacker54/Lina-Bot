const ms = require('parse-ms')
const db = require('quick.db')
const Discord = require('discord.js')

exports.run = async (client, message, args, config) => {

  let user = message.mentions.users.first() ||message.author 

  let timeout = 3600000 
  let carninha = 10
  let tubarão = 125
  let baleia = 200
  let bigbaleia = 300
  let munição = 1

  var list = [
`${carninha}`,
`${tubarão}`,
`${baleia}`,
`${bigbaleia}`
];

var rand = list[Math.floor(Math.random() * list.length)];

  let weekly = await db.fetch(`cacando_${message.author.id}`);

 
    if (weekly !== null && timeout - (Date.now() - weekly) > 0) {
        let time = ms(timeout - (Date.now() - weekly));
       
        message.channel.send(embed)
    } else {
  let bala = db.fetch(`bala_${message.author.id}`)

   let pistola = db.fetch(`pistola_${message.author.id}`)
    let cacador = db.fetch(`cacador_${message.author.id}`)
  
  
    if (pistola === null) {
        return message.channel.send(`É necessario ter uma arma de caça para caçar`)
    }
    
  let embed2 = new Discord.MessageEmbed()
  .setColor('#303136')
  .setDescription(`Ops Você precisa ter o emprego de caçador pra poder caçar`)
      if (cacador === null) {
        return message.channel.send(embed2)
    }
       
  let embed3 = new Discord.MessageEmbed()
  .setColor('#303136')
  .setDescription(`Ops Você precisa comprar Balas para sua arma`)
   if (bala === null) {
        return message.channel.send(embed3)
    }  

     let embed = new Discord.MessageEmbed()
    .setTitle(`Você matou um animal`)
    .setColor("#303136")
    .setDescription(`${message.author}, Você caçou e ganhou ${rand} De Carne `)
    .setFooter(`•${message.author.tag}`, message.author.displayAvatarURL({format: "png"}));

    message.channel.send(embed)
    db.add(`carne_${message.author.id}`, rand)
    db.subtract(`bala_${message.author.id}`, munição)
    db.set(`cacando_${message.author.id}`, Date.now())

    }
}