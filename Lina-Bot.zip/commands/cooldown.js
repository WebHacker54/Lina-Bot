const Discord = require('discord.js')

client.on('message', message => {
const talkedRecently = new Set();
 if (talkedRecently.has(message.author.id))
  return message.channel.send('calma aí seu gay').then(msg => {
    msg.delete( { timeout : 3500 } )
  });
talkedRecently.add(message.author.id);
setTimeout(() => {
  talkedRecently.delete(message.author.id);
}, 4500);
});